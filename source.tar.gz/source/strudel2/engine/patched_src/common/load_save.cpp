// PATCHED, minimal stand-in for vital-web/src/common/load_save.cpp -- see
// load_save.h (this dir) for why. The four function bodies below are
// unmodified logic copies of the real LoadSave's (vital-web/src/common/
// load_save.cpp, read-only, lines noted per-function below) -- only the
// JUCE-desktop-app-only 1900+ other lines (config files, preset directories,
// SynthBase/MidiManager wiring) were dropped, since nothing in this headless
// engine build calls them.
#include "load_save.h"
#include "utils.h"

#include <cstring>
#include <memory>

// vital-web/src/common/load_save.cpp:60-91 (LoadSave::convertBufferToPcm /
// convertPcmToFloatBuffer), unmodified.
void LoadSave::convertBufferToPcm(json& data, const std::string& field) {
  if (data.count(field) == 0)
    return;

  MemoryOutputStream decoded;
  std::string wave_data = data[field];
  Base64::convertFromBase64(decoded, wave_data);
  int size = static_cast<int>(decoded.getDataSize()) / sizeof(float);
  std::unique_ptr<float[]> float_data = std::make_unique<float[]>(size);
  memcpy(float_data.get(), decoded.getData(), size * sizeof(float));
  std::unique_ptr<int16_t[]> pcm_data = std::make_unique<int16_t[]>(size);
  vital::utils::floatToPcmData(pcm_data.get(), float_data.get(), size);

  String encoded = Base64::toBase64(pcm_data.get(), sizeof(int16_t) * size);
  data[field] = encoded.toStdString();
}

void LoadSave::convertPcmToFloatBuffer(json& data, const std::string& field) {
  if (data.count(field) == 0)
    return;

  MemoryOutputStream decoded;
  std::string wave_data = data[field];
  Base64::convertFromBase64(decoded, wave_data);
  int size = static_cast<int>(decoded.getDataSize()) / sizeof(int16_t);
  std::unique_ptr<int16_t[]> pcm_data = std::make_unique<int16_t[]>(size);
  memcpy(pcm_data.get(), decoded.getData(), size * sizeof(int16_t));
  std::unique_ptr<float[]> float_data = std::make_unique<float[]>(size);
  vital::utils::pcmToFloatData(float_data.get(), pcm_data.get(), size);

  String encoded = Base64::toBase64(float_data.get(), sizeof(float) * size);
  data[field] = encoded.toStdString();
}

// vital-web/src/common/load_save.cpp:1911-1924 (LoadSave::compareVersionStrings),
// unmodified.
int LoadSave::compareVersionStrings(String a, String b) {
  a = a.trim();
  b = b.trim();

  if (a.isEmpty() && b.isEmpty())
    return 0;

  String major_version_a = a.upToFirstOccurrenceOf(".", false, true);
  String major_version_b = b.upToFirstOccurrenceOf(".", false, true);

  if (!major_version_a.containsOnly("0123456789"))
    major_version_a = String("0");
  if (!major_version_b.containsOnly("0123456789"))
    major_version_b = String("0");

  int major_value_a = major_version_a.getIntValue();
  int major_value_b = major_version_b.getIntValue();

  if (major_value_a > major_value_b)
    return 1;
  else if (major_value_a < major_value_b)
    return -1;
  return compareVersionStrings(a.fromFirstOccurrenceOf(".", false, true),
                                b.fromFirstOccurrenceOf(".", false, true));
}

// vital-web/src/common/load_save.cpp:1903-1909 (LoadSave::compareFeatureVersionStrings),
// unmodified.
int LoadSave::compareFeatureVersionStrings(String a, String b) {
  a = a.trim();
  b = b.trim();

  return compareVersionStrings(a.upToLastOccurrenceOf(".", false, true),
                                b.upToLastOccurrenceOf(".", false, true));
}
