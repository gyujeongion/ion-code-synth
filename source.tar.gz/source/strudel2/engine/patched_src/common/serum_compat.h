#pragma once
#include "synth_constants.h"
// Each modularized WASM instance owns one engine and one copy of this state.
namespace vital {
class Wavetable;
inline bool serum_oscillator_model = false;
inline bool serum_envelope_model = false;
inline const Wavetable* serum_wavetables[kNumOscillators] = {};
inline bool serum_linear_levels[kNumOscillators] = {};
inline bool serumLinearLevel(const Wavetable* table) {
  for (int i = 0; i < kNumOscillators; ++i)
    if (serum_wavetables[i] == table) return serum_linear_levels[i];
  return false;
}
inline void resetSerumModels() {
  serum_oscillator_model = false;
  serum_envelope_model = false;
  for (int i = 0; i < kNumOscillators; ++i) serum_linear_levels[i] = false;
}
}
