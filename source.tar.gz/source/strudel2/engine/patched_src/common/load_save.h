// PATCHED, minimal stand-in for vital-web/src/common/load_save.h.
//
// wavetable_creator.cpp's updateJson()/jsonToState() (Vital's own preset
// version-migration logic for a single wavetable's JSON) references exactly
// four static LoadSave members: convertBufferToPcm, convertPcmToFloatBuffer,
// compareVersionStrings, compareFeatureVersionStrings. The real load_save.h
// declares those alongside the ENTIRE LoadSave class (config/preset file
// I/O, CriticalSection, Array<File>, MidiManager*, StringLayout* -- all
// JUCE-desktop-app surface unrelated to JSON state (de)serialization, and
// none of it is called anywhere in our wavetable compile unit).
//
// Real load_save.cpp (1956 lines) is NOT compiled at all in this build --
// only wavetable_creator.cpp/wavetable_component_factory.cpp/file_source.cpp
// (which also only use these same four statics) need *a* LoadSave
// declaration to link against, and load_save.cpp is far too entangled with
// SynthBase/MidiManager/file-system JUCE APIs (none of which this headless
// engine build has) to compile as-is. This file is used INSTEAD of the real
// one via include-path priority (engine/patched_src is searched before
// vital-web/src/common in build.sh) -- vital-web itself is never modified.
//
// See load_save.cpp (this dir) for the matching minimal implementations,
// which are byte-for-byte logic copies of the real LoadSave's bodies for
// these four functions (see engine/wrapper.cpp's v2_load_preset_json for
// the citation of exactly which lines they were copied from).
#pragma once

#include "JuceHeader.h"
#include "json/json.h"

using json = nlohmann::json;

class LoadSave {
  public:
    static void convertBufferToPcm(json& data, const std::string& field);
    static void convertPcmToFloatBuffer(json& data, const std::string& field);
    static int compareVersionStrings(String a, String b);
    static int compareFeatureVersionStrings(String a, String b);
};
