// C API wrapper around Vital's SoundEngine (src/synthesis/synth_engine/sound_engine.h)
// for the Strudel 2 feasibility spike. Exposes a tiny surface via emscripten's
// extern "C" + EMSCRIPTEN_KEEPALIVE so it can be called from JS/WASM glue
// with simple ccall/cwrap signatures, both in Node (offline render/test) and
// inside an AudioWorkletGlobalScope (no pthreads/SharedArrayBuffer needed --
// everything here is synchronous, single-threaded).
#include <cmath>
#include <cstdint>
#include <cstring>
#include <memory>
#include <string>
#include <vector>

#include "sound_engine.h"
#include "synth_parameters.h"
#include "wave_frame.h"
#include "wavetable.h"
#include "synth_voice_handler.h"
#include "modulation_connection_processor.h"
#include "value.h"
#include "smooth_value.h"
#include "value_switch.h"
#include "line_generator.h"
#include "serum_compat.h"
#include "synth_constants.h"
#include "sample_source.h"
#include "wavetable_creator.h"
#include "load_save.h"
#include "json/json.h"

using json = nlohmann::json;

#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#else
#define EMSCRIPTEN_KEEPALIVE
#endif

namespace {

// One global engine instance -- sufficient for this spike (one voice-per-note
// AudioWorkletProcessor instance would each get their own wasm instance in
// practice; a real Strudel integration could extend this to a small table of
// engine instances keyed by id, but the C API below is written so that would
// be a drop-in change).
struct EngineState {
  std::unique_ptr<vital::SoundEngine> engine;
  vital::control_map controls;
  int sample_rate = 44100;
  // M7: mirrors SynthBase::wavetable_creators_ (common/synth_base.h) --
  // SoundEngine itself only owns the DSP-facing vital::Wavetable per
  // oscillator (getWavetable()); the *authoring* pipeline (groups/
  // components/modifiers, .vital preset "wavetables" JSON) is a SynthBase-
  // level concept with no engine-level equivalent, so this wrapper (which
  // deliberately has no SynthBase/JUCE GUI layer) must own its own
  // WavetableCreator instances the same way SynthBase does.
  std::unique_ptr<WavetableCreator> wavetable_creators[vital::kNumOscillators];
};

EngineState* g_state = nullptr;

// M7: fields Vital's real preset loader would populate/support that this
// headless loader intentionally does not (or could not verify), collected
// during v2_load_preset_json() and readable via v2_get_load_warnings() --
// see that function for what can append here. Keeps the loader honest
// instead of silently dropping unsupported preset content.
std::string g_last_load_warnings;

vital::Value* findControl(const std::string& name) {
  if (!g_state)
    return nullptr;
  auto it = g_state->controls.find(name);
  if (it == g_state->controls.end())
    return nullptr;
  return it->second;
}

// M11 (see REPORT_M11.md "smoothing snap"): identical fix to the M10
// setHard() loop inside v2_load_preset_json() below, factored out so it can
// ALSO be called from the grammar/patch-registration path (v2_set_param(),
// as used by web/worklet.js's applyOps()/registerPatch() and
// translate/render_strudel2.mjs) -- that path has the exact same bug:
// SmoothValue::set() only moves the smoothing TARGET, current_value_ keeps
// ramping from whatever it was (the constructor default) unless snapped.
// registerPatch() calls v2_set_param() many times in a row, once per patch
// field, then immediately lets notes play -- same shape as
// v2_load_preset_json()'s loadControls loop, same leak (confirmed by a
// minimal repro: sample_on=1/sample_level=0 set via v2_set_param then an
// IMMEDIATE noteOn measured -23.4dB RMS in the first 20ms where native/
// settled behavior is silence, see REPORT_M11.md). Deliberately NOT called
// from any PER-NOTE path (.vset() raw overrides / worklet.js's patchEvent
// 'vset' handling, or the legacy setParamNow() live-tweak path) -- smoothing
// there is desired (avoids audible zipper/click artifacts when a running
// note's parameter changes), only patch REGISTRATION (before any note has
// sounded) should snap.
void snapSmoothedControls() {
  if (!g_state)
    return;
  for (auto& control : g_state->controls) {
    if (auto* smooth = dynamic_cast<vital::SmoothValue*>(control.second))
      smooth->setHard(smooth->value());
    else if (auto* cr_smooth = dynamic_cast<vital::cr::SmoothValue*>(control.second))
      cr_smooth->setHard(cr_smooth->value());
  }
}

// IMPORTANT FINDING (see REPORT.md "stubbed/behavioral" notes): a freshly
// constructed vital::SoundEngine is SILENT by design. Wavetable::
// loadDefaultWavetable() (called from Wavetable's own constructor) loads a
// single all-ZERO WaveFrame (WaveFrame's default ctor value-initializes
// time_domain[] to zero) -- in the real desktop app, actual waveform data
// only ever enters via loading a .vital preset or the wavetable
// editor/generators, none of which exist in this headless engine-only
// build. Without loading real frame data, noteOn()+process() runs the full
// voice/DSP graph correctly (voices activate, envelopes run, CPU cost is
// representative) but every oscillator sample is exactly 0. We discovered
// this via the offline test (CPU realtime factor looked plausible while
// pitch/RMS measurements were all silence), then confirmed the fix with
// v2_load_wavetable_frame(). This helper reproduces that fix as an
// out-of-the-box default so v2_create() alone is enough to hear something,
// without requiring every caller to know about this beforehand.
void loadDefaultSineIntoOscillator1(vital::SoundEngine* engine) {
  vital::Wavetable* wavetable = engine->getWavetable(0);  // osc_1
  if (!wavetable)
    return;
  vital::WaveFrame frame;
  frame.index = 0;
  static float sine[vital::WaveFrame::kWaveformSize];
  for (int i = 0; i < vital::WaveFrame::kWaveformSize; ++i)
    sine[i] = std::sin(2.0f * 3.14159265358979f * i / vital::WaveFrame::kWaveformSize);
  frame.loadTimeDomain(sine);
  wavetable->loadWaveFrame(&frame, 0);
  wavetable->postProcess(1.0f);
}

}  // namespace

extern "C" {

// create(sampleRate, maxBlock). maxBlock is accepted for API symmetry with
// the spec but the engine is driven internally in <=128-sample chunks
// (kMaxBufferSize) regardless -- see process() below -- so no allocation
// depends on it.
EMSCRIPTEN_KEEPALIVE
int v2_create(int sample_rate, int max_block) {
  vital::resetSerumModels();
  (void)max_block;
  if (g_state) {
    delete g_state;
    g_state = nullptr;
  }
  g_state = new EngineState();
  g_state->engine = std::make_unique<vital::SoundEngine>();
  g_state->engine->setSampleRate(sample_rate);
  g_state->sample_rate = sample_rate;
  g_state->controls = g_state->engine->getControls();

  // M2 FIX (see REPORT_M2.md "oversampling never resynced"): SoundEngine's
  // constructor (SoundEngine::init(), sound_engine.cpp) hardcodes
  // setOversamplingAmount(kDefaultOversamplingAmount=2, kDefaultSampleRate=
  // 44100) as a startup placeholder -- in the real desktop app this is
  // ALWAYS immediately superseded by SynthBase::checkOversampling()
  // (common/synth_base.cpp:323/758, common/load_save.cpp:1050), which reads
  // the actual "oversampling" control (ValueDetails default 0.0 ->
  // 1<<0 = 1x, NOT 2x) and the actual current sample rate
  // (SoundEngine::getSampleRate(), just set above) and calls
  // setOversamplingAmount() again with the CORRECT values. This wrapper
  // never used SynthBase at all, so checkOversampling() (public on
  // SoundEngine, sound_engine.h:96) was never called -- the engine ran
  // permanently stuck at the constructor's 2x/44100-derived oversampling
  // state regardless of what sample_rate v2_create() was actually given.
  // Calling it here (matching the real app's own post-setSampleRate
  // sequence) makes every per-voice processor's getOversampleAmount()/
  // getSampleRate() consistent with the ACTUAL output sample rate and the
  // "oversampling" control's real (default 1x) value.
  g_state->engine->checkOversampling();

  // M7: construct this instance's WavetableCreators now (mirrors
  // SynthBase's constructor loop, common/synth_base.cpp:39-44) so
  // v2_load_preset_json() always has somewhere to load "wavetables" JSON
  // into, matching real Vital's lifetime (one WavetableCreator per
  // oscillator, for the lifetime of the synth instance, not re-created per
  // preset load -- WavetableCreator::jsonToState() below clears/rebuilds
  // its own groups_ each call, same as loading a new preset in the real app
  // reuses the same WavetableCreator objects).
  for (int i = 0; i < vital::kNumOscillators; ++i) {
    vital::Wavetable* wavetable = g_state->engine->getWavetable(i);
    vital::serum_wavetables[i] = wavetable;
    if (wavetable) {
      g_state->wavetable_creators[i] = std::make_unique<WavetableCreator>(wavetable);
      g_state->wavetable_creators[i]->init();
    }
  }

  // Deliberately minimal here: Vital's own ValueDetails.default_value (see
  // synth_parameters.cpp) already gives every control a sane default at
  // construction time -- osc_1_on defaults to 1 (on), "volume" defaults to
  // ~5473 out of its [0, 7399.44] sqrt-scaled dB range (NOT a 0..1 range --
  // an earlier version of this function set volume=1.0f assuming 0..1,
  // which is nearly silent on this param's real scale; that bug produced
  // ~0 RMS output with an otherwise-plausible CPU realtime factor, caught
  // via the offline pitch-detection test returning noise). filter_1_on
  // defaults to 0 (off), which is what we want so pure-oscillator
  // pitch/param tests below aren't filtered unless a test opts in.
  auto setIfPresent = [](const std::string& name, float value) {
    vital::Value* v = findControl(name);
    if (v)
      v->set(value);
  };
  setIfPresent("env_1_release", 0.3f);

  // See loadDefaultSineIntoOscillator1() above: without this, the engine is
  // silent out of the box.
  loadDefaultSineIntoOscillator1(g_state->engine.get());

  return 0;
}

EMSCRIPTEN_KEEPALIVE
void v2_destroy() {
  if (g_state) {
    delete g_state;
    g_state = nullptr;
  }
}

EMSCRIPTEN_KEEPALIVE
void v2_note_on(int midi, float velocity) {
  if (!g_state)
    return;
  g_state->engine->noteOn(midi, velocity, 0, 0);
}

EMSCRIPTEN_KEEPALIVE
void v2_note_off(int midi) {
  if (!g_state)
    return;
  g_state->engine->noteOff(midi, 0.0f, 0, 0);
}

EMSCRIPTEN_KEEPALIVE
void v2_all_notes_off() {
  if (!g_state)
    return;
  g_state->engine->allSoundsOff();
}

// process(outL, outR, frames): renders `frames` stereo samples into the two
// caller-owned float buffers. Internally chunks into <=kMaxBufferSize (128)
// sample blocks because that's the engine's native block size (also
// conveniently exactly one AudioWorklet render quantum).
EMSCRIPTEN_KEEPALIVE
void v2_process(float* out_l, float* out_r, int frames) {
  if (!g_state || !g_state->engine) {
    if (out_l) memset(out_l, 0, sizeof(float) * frames);
    if (out_r) memset(out_r, 0, sizeof(float) * frames);
    return;
  }

  vital::SoundEngine* engine = g_state->engine.get();
  int done = 0;
  while (done < frames) {
    int chunk = frames - done;
    if (chunk > vital::kMaxBufferSize)
      chunk = vital::kMaxBufferSize;

    engine->process(chunk);
    const vital::mono_float* buf = (const vital::mono_float*)engine->output(0)->buffer;
    int stride = vital::poly_float::kSize;
    for (int i = 0; i < chunk; ++i) {
      out_l[done + i] = buf[stride * i + 0];
      out_r[done + i] = buf[stride * i + 1];
    }
    done += chunk;
  }
}

// set_param_by_name(name, value): value is in the parameter's native Vital
// range (see synth_parameters.cpp / vital::Parameters::getDetails), clamped
// to [min, max]. Returns 1 on success, 0 if the name is unknown.
EMSCRIPTEN_KEEPALIVE
int v2_set_param(const char* name, float value) {
  if (!g_state || !name)
    return 0;
  std::string key(name);
  if (key == "serum_envelope_model") {
    vital::serum_envelope_model = value >= 0.5f;
    return 1;
  }
  if (key == "serum_oscillator_model") {
    vital::serum_oscillator_model = value >= 0.5f;
    return 1;
  }
  for (int i = 0; i < vital::kNumOscillators; ++i) {
    if (key == "osc_" + std::to_string(i + 1) + "_serum_linear_level") {
      vital::serum_linear_levels[i] = value >= 0.5f;
      return 1;
    }
  }
  vital::Value* control = findControl(key);
  if (!control)
    return 0;

  if (vital::Parameters::isParameter(key)) {
    const vital::ValueDetails& details = vital::Parameters::getDetails(key);
    if (value < details.min) value = details.min;
    if (value > details.max) value = details.max;
  }
  control->set(value);
  // The preset loader finalizes this explicitly. The scalar API is also
  // used by grammar patches and live edits; updating only the control
  // leaves their DSP at the construction-time oversampling rate.
  if (key == "oversampling")
    g_state->engine->checkOversampling();
  return 1;
}

// M11: snap_smoothed_controls() -- public C API for snapSmoothedControls()
// (see its comment above findControl()). Callers: web/worklet.js's
// registerPatch(), immediately after applyOps() finishes setting every
// param for a newly-registered patch, before that patch can receive any
// noteOn/patchEvent; translate/render_strudel2.mjs's offline harness, same
// spot. NOT called after per-note .vset()/patchEvent('vset') overrides or
// the legacy live setParam() path -- those should keep smoothing.
EMSCRIPTEN_KEEPALIVE
void v2_snap_smoothed_controls() {
  snapSmoothedControls();
}

EMSCRIPTEN_KEEPALIVE
float v2_get_param(const char* name) {
  if (!g_state || !name)
    return 0.0f;
  if (std::string(name) == "serum_envelope_model")
    return vital::serum_envelope_model ? 1.0f : 0.0f;
  if (std::string(name) == "serum_oscillator_model")
    return vital::serum_oscillator_model ? 1.0f : 0.0f;
  for (int i = 0; i < vital::kNumOscillators; ++i)
    if (std::string(name) == "osc_" + std::to_string(i + 1) + "_serum_linear_level")
      return vital::serum_linear_levels[i] ? 1.0f : 0.0f;
  vital::Value* control = findControl(std::string(name));
  if (!control)
    return 0.0f;
  return control->value();
}

EMSCRIPTEN_KEEPALIVE
float v2_get_param_min(const char* name) {
  if (!vital::Parameters::isParameter(std::string(name)))
    return 0.0f;
  return vital::Parameters::getDetails(std::string(name)).min;
}

EMSCRIPTEN_KEEPALIVE
float v2_get_param_max(const char* name) {
  if (!vital::Parameters::isParameter(std::string(name)))
    return 1.0f;
  return vital::Parameters::getDetails(std::string(name)).max;
}

// load_wavetable_frame(osc_index, frame_index, samples[2048]): loads one
// 2048-sample time-domain frame into oscillator `osc_index`'s wavetable at
// slot `frame_index`, exactly as Vital's own wavetable editor would via
// Wavetable::loadWaveFrame(). osc_index is 1..3 (matches osc_1/osc_2/osc_3).
EMSCRIPTEN_KEEPALIVE
int v2_load_wavetable_frame(int osc_index, int frame_index, const float* samples, int num_samples) {
  if (!g_state || !g_state->engine || !samples)
    return 0;
  if (num_samples != vital::WaveFrame::kWaveformSize)
    return 0;  // must be exactly 2048 samples, matching Vital's WaveFrame size.

  vital::Wavetable* wavetable = g_state->engine->getWavetable(osc_index - 1);
  if (!wavetable)
    return 0;

  if (frame_index >= 1) {
    // setNumFrames requires the target index to exist; Wavetable's own max
    // frame count is bounded by kMaxSourceValue at construction, so clamp.
    wavetable->setNumFrames(frame_index + 1);
  }

  vital::WaveFrame frame;
  frame.index = frame_index;
  frame.loadTimeDomain(const_cast<float*>(samples));
  wavetable->loadWaveFrame(&frame, frame_index);
  // M2 FIX (root cause of the M1 "wt.frames pos0 renders a square-like
  // spectrum instead of the loaded sine" bug -- see REPORT_M2.md and
  // REPORT_PHASE1_M1.md item 3): Wavetable::postProcess(max_span) is NOT
  // idempotent -- read synthesis/lookups/wavetable.cpp:111-124: with
  // max_span>0 it computes `scale = 2.0f/max_span` and multiplies EVERY
  // already-loaded frame's wave_data AND frequency_amplitudes by `scale`,
  // every time it's called (not just the newly-loaded one). This function
  // used to call postProcess(1.0f) (scale=2.0) after EVERY single frame
  // load. grammar.mjs's wt.frames() compiler loads frame 0 first, then up
  // to ~32 intermediate morph frames, then the final keyframe -- so frame
  // 0's amplitude was getting doubled again on every one of those
  // subsequent loads (~2^32x for a typical 2-keyframe morph), completely
  // blowing out its spectrum into distortion (measured as "square-like").
  // Fixed: postProcess is no longer called here at all -- callers must call
  // the new v2_wavetable_postprocess() explicitly, exactly ONCE, after ALL
  // frames for a given oscillator have been loaded (matches how Vital's own
  // wavetable editor / .vital preset loader actually uses this API: load
  // every frame of the table, then post-process once).
  return 1;
}

// wavetable_postprocess(osc_index): call exactly ONCE per oscillator after
// every v2_load_wavetable_frame() call for that oscillator's full frame set
// is done (see the FIX note above -- postProcess is destructive/cumulative
// across the whole table, not per-frame). max_span=1.0f (scale=2.0f) matches
// Vital's own default full-scale wavetable normalization.
EMSCRIPTEN_KEEPALIVE
int v2_wavetable_postprocess(int osc_index) {
  if (!g_state || !g_state->engine)
    return 0;
  vital::Wavetable* wavetable = g_state->engine->getWavetable(osc_index - 1);
  if (!wavetable)
    return 0;
  wavetable->postProcess(1.0f);
  return 1;
}

// M11 (see REPORT_M11.md "wavetable via WavetableCreator"): load_wavetable_json
// (osc_index, json_text) -- loads ONE oscillator's wavetable through Vital's
// REAL authoring pipeline (WavetableCreator::jsonToState()+render(), the
// exact same call the native-preset loader below uses per-oscillator via
// g_state->wavetable_creators[i]), instead of the raw-frame bypass
// (v2_load_wavetable_frame()+v2_wavetable_postprocess() above). json_text is
// ONE element of a .vital preset's top-level "wavetables" array -- i.e. the
// same {"groups":[{"components":[{"type":"Wave Source","interpolation":...,
// "interpolation_style":...,"keyframes":[{"position":0..256,"wave_data":
// base64(float32[2048] time-domain samples)}, ...]}]}], "name":...,
// "author":...,"remove_all_dc":...,"full_normalize":...} shape (confirmed
// against a real serum2vital-produced .vital file's "wavetables[i]" --
// wave_data is exactly JUCE Base64::toBase64() of the raw little-endian
// float32 time-domain bytes, decoded back the same way by
// WaveSourceKeyframe::jsonToState(), common/wavetable/wave_source.cpp).
// grammar.mjs's wt.harmonics/wt.expr/wt.frames keep their existing surface
// syntax; only compilePatch()'s internal compiled-op shape changes (a single
// 'wavetableJson' op with this JSON payload, built by a new grammar.mjs
// helper, replacing the old per-slot manual-interpolation 'wavetable' op
// loop) -- see grammar.mjs buildWavetableJson().
//
// Unlike v2_load_wavetable_frame(), no separate postprocess call is needed
// (render() below already does WavetableCreator's own DC-removal/
// normalization pipeline, same as the native preset loader) and Vital's OWN
// keyframe interpolation (WaveSource's kTime/kFrequency blend + the
// component's kNone/kLinear/kCubic keyframe-span style) runs for any
// in-between wave_frame positions instead of grammar.mjs's old manual
// 32-step per-morph JS-side linear time-domain lerp.
EMSCRIPTEN_KEEPALIVE
int v2_load_wavetable_json(int osc_index, const char* json_text) {
  if (!g_state || !g_state->engine || !json_text)
    return 0;
  if (osc_index < 1 || osc_index > vital::kNumOscillators)
    return 0;
  if (!g_state->wavetable_creators[osc_index - 1])
    return 0;

  json wavetable_json;
  try {
    wavetable_json = json::parse(json_text);
  } catch (const json::exception& e) {
    g_last_load_warnings += std::string("v2_load_wavetable_json parse error: ") + e.what() + "\n";
    return 0;
  }

  try {
    WavetableCreator* creator = g_state->wavetable_creators[osc_index - 1].get();
    creator->jsonToState(wavetable_json);
    creator->render();
  } catch (const json::exception& e) {
    g_last_load_warnings += "osc " + std::to_string(osc_index) +
        " v2_load_wavetable_json jsonToState/render failed: " + e.what() + "\n";
    return 0;
  }
  return 1;
}

// M12 (see REPORT_M12.md "sample layer"): load_sample_json(json_text) --
// loads Vital's single global noise/sample module through the SAME call the
// native-preset loader above uses (engine->getSample()->jsonToState()), for
// the grammar/translator path. json_text is the same shape a .vital
// preset's top-level "settings.sample" object takes -- {"name":string,
// "length":int,"sample_rate":int,"samples":base64(int16 PCM LE bytes)}
// (confirmed against Sample::stateToJson()/jsonToState(),
// synthesis/producers/sample_source.cpp) -- optionally "samples_stereo" for
// a stereo sample (unused by grammar.mjs's buildNoiseSampleJson(), which
// only ever emits mono deterministic noise). Unlike the wavetable JSON path
// there is only ONE sample module for the whole patch (not per-oscillator),
// matching Vital's own architecture (SoundEngine::getSample() is a single
// pointer, not an array) -- see GRAMMAR.md's `sample: {...}` (patch-level,
// not per-osc) field.
EMSCRIPTEN_KEEPALIVE
int v2_load_sample_json(const char* json_text) {
  if (!g_state || !g_state->engine || !json_text)
    return 0;
  vital::Sample* sample = g_state->engine->getSample();
  if (!sample)
    return 0;

  json sample_json;
  try {
    sample_json = json::parse(json_text);
  } catch (const json::exception& e) {
    g_last_load_warnings += std::string("v2_load_sample_json parse error: ") + e.what() + "\n";
    return 0;
  }

  try {
    sample->jsonToState(sample_json);
  } catch (const json::exception& e) {
    g_last_load_warnings += std::string("v2_load_sample_json jsonToState failed: ") + e.what() + "\n";
    return 0;
  }
  return 1;
}

// M7: load_preset_json(json_text) -- loads a full .vital preset (the same
// JSON a .vital file's contents are) exactly the way real Vital's
// LoadSave::jsonToState() (common/load_save.cpp:1027-1053, read-only
// reference, reproduced here since load_save.cpp itself is SynthBase/JUCE-
// GUI-entangled and not compiled into this headless engine -- see
// patched_src/common/load_save.h/.cpp for the one small slice of LoadSave
// that IS compiled, its version-string utilities) does, minus the parts
// that only matter for a live desktop GUI app (SynthBase's async
// modulation-change queue -- applying synchronously here is equivalent
// since no audio has been generated yet at load time; modWheelGuiChanged();
// save_info/preset-browser bookkeeping).
//
// Order matches jsonToState() exactly: loadControls -> loadModulations ->
// loadSample -> loadWavetables -> loadLfos -> checkOversampling. This order
// is load-bearing: loadModulations relies on loadControls having already
// set every "modulation_N_amount/power/bipolar/stereo/bypass" control from
// the flat settings map (see loadControls's reference implementation below
// -- modulation scalars are NOT special-cased, they're just named controls
// like any other Vital parameter), and loadWavetables/loadLfos build actual
// waveform/LFO-shape state that checkOversampling's oversampling-amount
// resync must see.
//
// Returns 1 on success, 0 on failure (bad JSON, or synth_version newer than
// this engine's ProjectInfo::versionString="1.0.6" -- see shim/JuceHeader.h
// -- which real Vital also refuses to load). Call v2_get_load_warnings()
// after a successful load to see what (if anything) was skipped.
EMSCRIPTEN_KEEPALIVE
int v2_load_preset_json(const char* json_text) {
  vital::resetSerumModels();
  g_last_load_warnings.clear();
  if (!g_state || !g_state->engine || !json_text)
    return 0;

  json data;
  try {
    data = json::parse(json_text);
  } catch (const json::exception& e) {
    g_last_load_warnings += std::string("JSON parse error: ") + e.what() + "\n";
    return 0;
  }

  if (!data.count("synth_version") || !data.count("settings")) {
    g_last_load_warnings += "missing synth_version or settings\n";
    return 0;
  }

  std::string version = data["synth_version"].get<std::string>();

  // load_save.cpp:1030-1032 -- refuse presets saved by a strictly newer
  // Vital feature version than this engine (ProjectInfo::versionString).
  if (LoadSave::compareFeatureVersionStrings(String(version), String(ProjectInfo::versionString)) > 0) {
    g_last_load_warnings += "preset synth_version (" + version +
        ") is newer than this engine's (" + std::string(ProjectInfo::versionString) + ")\n";
    return 0;
  }

  // load_save.cpp:1034-1036 -- LoadSave::updateFromOldVersion() is ~700
  // lines of preset-schema migration for versions going back to Vital's
  // earliest releases (sub_octave rename, wavetable PCM<->float encoding
  // changes, filter model renumbering, etc). Per M7's scope (presets here
  // are already normalized to synth_version 1.0.6 by vital_compat.py before
  // reaching this loader), it is NOT reimplemented -- if a preset actually
  // needs it, that is flagged here rather than silently producing wrong
  // output.
  int compare_versions = LoadSave::compareVersionStrings(String(version), String(ProjectInfo::versionString));
  bool needs_old_version_migration =
      compare_versions < 0 || (data["settings"].count("sub_octave") != 0);
  if (needs_old_version_migration) {
    g_last_load_warnings += "preset needs LoadSave::updateFromOldVersion() migration (from " +
        version + ") -- NOT IMPLEMENTED, loading settings as-is (may be wrong)\n";
  }

  json settings = data["settings"];
  json modulations = settings.count("modulations") ? settings["modulations"] : json::array();
  json wavetables = settings.count("wavetables") ? settings["wavetables"] : json::array();
  json lfos = settings.count("lfos") ? settings["lfos"] : json::array();

  vital::SoundEngine* engine = g_state->engine.get();

  // --- loadControls (load_save.cpp:153-168) ---
  // Every registered control is set from `settings` if present, else reset
  // to its ValueDetails default -- this is also what resets every
  // modulation_N_amount/power/bipolar/stereo/bypass slot not present in a
  // sparse settings map, and every osc/filter/env/lfo/macro/effect param.
  for (auto& control : g_state->controls) {
    const std::string& name = control.first;
    if (settings.count(name)) {
      vital::mono_float value = settings[name].get<vital::mono_float>();
      control.second->set(value);
    } else if (vital::Parameters::isParameter(name)) {
      vital::ValueDetails details = vital::Parameters::getDetails(name);
      control.second->set(details.default_value);
    }
  }
  // modWheelGuiChanged(controls["mod_wheel"]->value()) (load_save.cpp:167)
  // is GUI-only bookkeeping (updates a MIDI controller mirror for display);
  // deliberately not reproduced -- no DSP effect, mod_wheel's actual value
  // is already set by the loop above like any other control.

  // --- loadModulations (load_save.cpp:170-196), inlined SynthBase::
  // connectModulation(ModulationConnection*)/createModulationChange()
  // (synth_base.cpp:137-179) since there is no SynthBase here. NOTE: this
  // uses ModulationConnectionBank::atIndex() directly (fixed preset-order
  // slots), NOT createConnection() -- createConnection() additionally calls
  // setBipolar() to a source-default, which would stomp the bipolar value
  // loadControls() (above) just set from the preset's own
  // "modulation_N_bipolar" control. Real LoadSave::loadModulations avoids
  // this the same way (see load_save.cpp:170-196, read-only reference).
  {
    vital::ModulationConnectionBank& bank = engine->getModulationBank();
    int index = 0;
    for (const json& modulation : modulations) {
      if (index >= vital::kMaxModulationConnections)
        break;
      std::string source = modulation.value("source", "");
      std::string destination = modulation.value("destination", "");
      vital::ModulationConnection* connection = bank.atIndex(index);
      index++;

      vital::Output* source_out = engine->getModulationSource(source);
      vital::Processor* mono_dest = engine->getMonoModulationDestination(destination);
      if (source_out == nullptr || mono_dest == nullptr)
        continue;

      if (!source.empty() && !destination.empty()) {
        connection->source_name = source;
        connection->destination_name = destination;

        // createModulationChange (synth_base.cpp:137-161)
        vital::modulation_change change;
        change.source = source_out;
        change.mono_destination = mono_dest;
        change.mono_modulation_switch = engine->getMonoModulationSwitch(destination);
        change.destination_scale = vital::Parameters::getParameterRange(destination);
        change.poly_modulation_switch = engine->getPolyModulationSwitch(destination);
        change.poly_destination = engine->getPolyModulationDestination(destination);
        change.modulation_processor = connection->modulation_processor.get();

        int num_audio_rate = 0;
        for (int i = 0; i < vital::kMaxModulationConnections; ++i) {
          vital::ModulationConnection* other = bank.atIndex(i);
          if (other->source_name == connection->source_name &&
              other->destination_name != connection->destination_name &&
              !other->modulation_processor->isControlRate()) {
            num_audio_rate++;
          }
        }
        change.num_audio_rate = num_audio_rate;
        change.disconnecting = false;

        // isInvalidConnection (synth_base.cpp:164-166)
        bool invalid = change.poly_destination &&
            change.poly_destination->router() == change.modulation_processor;
        if (invalid) {
          connection->destination_name = "";
          connection->source_name = "";
        } else {
          engine->connectModulation(change);
        }
      }

      if (modulation.count("line_mapping"))
        connection->modulation_processor->lineMapGenerator()->jsonToState(modulation["line_mapping"]);
      else
        connection->modulation_processor->lineMapGenerator()->initLinear();
    }
  }

  // --- loadSample (load_save.cpp:198-202) ---
  if (settings.count("sample")) {
    vital::Sample* sample = engine->getSample();
    if (sample) {
      try {
        sample->jsonToState(settings["sample"]);
      } catch (const json::exception& e) {
        g_last_load_warnings += std::string("sample jsonToState failed: ") + e.what() + "\n";
      }
    }
  }

  // --- loadWavetables (load_save.cpp:204-215) ---
  // This is the M7 headline fix over M1-M6's v2_load_wavetable_frame()
  // bypass: WavetableCreator::jsonToState() rebuilds the real groups/
  // components/modifiers graph (wave_source.cpp keyframes with kTime/
  // kFrequency interpolation styles, phase/warp/fold/window/frequency-filter/
  // slew modifiers, file_source-decoded audio) and ->render() runs Vital's
  // actual wavetable_creator.cpp::render()/postRender() pipeline --
  // including its own DC removal / full-scale normalization
  // (remove_all_dc_/full_normalize_, wavetable_creator.h:91-92) -- so the
  // separate v2_wavetable_postprocess() call is NOT needed/used here (that
  // call is specific to the raw-frame bypass path).
  {
    int i = 0;
    for (const json& wavetable_json : wavetables) {
      if (i >= vital::kNumOscillators)
        break;
      if (g_state->wavetable_creators[i]) {
        WavetableCreator* creator = g_state->wavetable_creators[i].get();
        try {
          creator->jsonToState(wavetable_json);
          creator->render();
        } catch (const json::exception& e) {
          g_last_load_warnings += "osc " + std::to_string(i + 1) +
              " wavetable jsonToState/render failed: " + e.what() + "\n";
        }
      }
      i++;
    }
  }

  // --- loadLfos (load_save.cpp:217-225) ---
  {
    int i = 0;
    for (const json& lfo_json : lfos) {
      if (i >= vital::kNumLfos)
        break;
      LineGenerator* lfo_source = engine->getLfoSource(i);
      if (lfo_source) {
        lfo_source->jsonToState(lfo_json);
        lfo_source->render();
      }
      i++;
    }
  }

  // preset_name/author/comments/preset_style/macroN display strings
  // (load_save.cpp:227-256, loadSaveState) are GUI/save-metadata only, no
  // DSP effect -- not reproduced. macroN's own VALUE (the macro knob
  // position, as opposed to its display name) is already set by the
  // loadControls loop above ("macro_control_1".."_4" are ordinary
  // controls, distinct from the "macroN" display-name strings loadSaveState
  // handles).

  engine->checkOversampling();

  // M10 FIX (lead, 2026-09-24): snap every smoothed control to its loaded
  // value. SmoothValue::set() only moves the target; current_value_ keeps
  // ramping from whatever it was (the constructor default), so a note played
  // right after loading heard e.g. sample_level gliding 0.7 -> 0 (measured:
  // sample_on=1, sample_level=0 leaked -21.9 dB RMS in the first 10 ms,
  // silent after a 1 s pre-roll; native Vital is silent immediately).
  // setHard() is Vital's own API for jumping current_value_ to the target.
  // M11: factored into snapSmoothedControls() (above) so the grammar/patch-
  // registration path can reuse the identical fix -- see that function's
  // comment.
  snapSmoothedControls();

  return 1;
}

// get_load_warnings(out_buf, buf_len): everything v2_load_preset_json()
// above skipped, could not verify, or fell back on for the most recently
// loaded preset (old-version migration needed, sample/wavetable JSON
// exceptions). Empty string means nothing was flagged. Truncates to
// buf_len-1 like v2_get_parameter_name().
EMSCRIPTEN_KEEPALIVE
int v2_get_load_warnings(char* out_buf, int buf_len) {
  if (!out_buf || buf_len <= 0)
    return 0;
  std::strncpy(out_buf, g_last_load_warnings.c_str(), buf_len - 1);
  out_buf[buf_len - 1] = '\0';
  return static_cast<int>(g_last_load_warnings.size());
}

// connect_modulation(source_name, dest_param_name, amount, bipolar): bonus
// feature -- wires up a modulation source (an LFO/envelope output name, e.g.
// "lfo_1") to a destination parameter (e.g. "filter_1_cutoff") with a given
// amount (-1..1). Returns 1 on success. This reproduces exactly what the
// Vital GUI does when you drag a mod source onto a knob: engine-level
// ModulationConnectionBank::createConnection() picks a free connection slot,
// SoundEngine::connectModulation() plugs it in, and the per-slot amount is
// just a normal named control ("modulation_<slot+1>_amount") that already
// exists and is pre-wired -- see SynthVoiceHandler::init() -- so we set it
// with the same v2_set_param() path used for every other parameter.
//
// M11 (see REPORT_M11.md "control diff"): `bipolar` added -- pass 0 or 1 to
// also set this connection's "modulation_<slot+1>_bipolar" control (using
// the SAME slot this call just resolved via createConnection(), so it is
// always the RIGHT connection regardless of what order patches connect
// mods in -- unlike a caller trying to guess a raw "modulation_N_bipolar"
// param name up front, which would depend on slot-assignment order and
// could silently stomp the WRONG connection's bipolar flag). Pass any
// negative value (e.g. -1, the grammar.mjs default when a mod spec doesn't
// say) to leave bipolar untouched (its existing/default value applies) --
// confirmed via m11_control_diff.mjs that the native preset loader sets a
// real, connection-specific bipolar flag on several actively-used mods that
// this grammar's mods[] previously had no way to express at all (bipolar
// flips a mod's effective range from destination_scale*amount*[0,1] to
// destination_scale*amount*[-1,1] -- audible, not cosmetic).
static int connectModulation(const char* source_name, const char* dest_name, float amount, float bipolar, float range) {
  if (!g_state || !g_state->engine || !source_name || !dest_name)
    return 0;

  vital::SoundEngine* engine = g_state->engine.get();
  vital::Output* source = engine->getModulationSource(source_name);
  if (!source)
    return 0;

  std::string dest_key(dest_name);
  vital::Processor* mono_dest = engine->getMonoModulationDestination(dest_key);
  vital::Processor* poly_dest = engine->getPolyModulationDestination(dest_key);
  if (!mono_dest)
    return 0;

  vital::ValueSwitch* mono_switch = engine->getMonoModulationSwitch(dest_key);
  vital::ValueSwitch* poly_switch = engine->getPolyModulationSwitch(dest_key);

  vital::ModulationConnectionBank& bank = engine->getModulationBank();
  vital::ModulationConnection* connection = bank.createConnection(source_name, dest_key);
  if (!connection)
    return 0;  // no free connection slot (kMaxModulationConnections exhausted).

  // [strudel2 phase0.5 fix, see REPORT_PHASE05.md "LFO"] destination_scale
  // used to be hardcoded to 1.0f here. Real Vital (common/synth_base.cpp's
  // SynthBase::createModulationChange(), line ~146) sets it to
  // vital::Parameters::getParameterRange(dest) = (max - min) of the
  // destination parameter -- see
  // ModulationConnectionProcessor::processAudioRateLinear(), which computes
  // dest_delta = (mod_source[-1..1] + bipolar_offset) * amount *
  // destination_scale. With destination_scale hardcoded to 1.0, every
  // modulation connection was under-scaled by the destination's whole
  // parameter range (128 for filter_1_cutoff, 96 for osc_1_transpose, etc)
  // -- e.g. an LFO->filter_1_cutoff connection at amount=0.8 (as the phase-0
  // spike used) was moving the cutoff by at most +/-0.8 raw units out of a
  // 128-unit range, i.e. an practically inaudible ~0.6% sweep. This is very
  // likely a root cause of SOL_AUDIT.md's "LFO 지표의 표준편차는 평균의
  // 0.5%" finding, independent of the (also real, see below) tempo-sync
  // default bug. Fixed to match real Vital's formula.
  vital::modulation_change change;
  change.source = source;
  change.mono_destination = mono_dest;
  change.poly_destination = poly_dest;
  change.destination_scale = range > 0.0f ? range : vital::Parameters::getParameterRange(dest_key);
  change.modulation_processor = connection->modulation_processor.get();
  change.mono_modulation_switch = mono_switch;
  change.poly_modulation_switch = poly_switch;
  change.disconnecting = false;
  change.num_audio_rate = 0;

  engine->connectModulation(change);

  int slot = connection->modulation_processor->index();
  std::string amount_name = "modulation_" + std::to_string(slot + 1) + "_amount";
  v2_set_param(amount_name.c_str(), amount);
  if (bipolar >= 0.0f) {
    std::string bipolar_name = "modulation_" + std::to_string(slot + 1) + "_bipolar";
    v2_set_param(bipolar_name.c_str(), bipolar);
  }
  return 1;
}

// Preserve the original ABI and native destination range for Vital code.
EMSCRIPTEN_KEEPALIVE
int v2_connect_modulation(const char* source, const char* dest, float amount, float bipolar) {
  return connectModulation(source, dest, amount, bipolar, 0.0f);
}

// Explicit physical span for source instruments whose destination range is
// different. Keeping amount in [-1,1] avoids silently clipping e.g. Serum's
// 128-semitone CoarsePit when translated into Vital's 96-semitone control.
EMSCRIPTEN_KEEPALIVE
int v2_connect_modulation_scaled(const char* source, const char* dest, float amount, float bipolar, float range) {
  if (!std::isfinite(range) || range <= 0.0f) return 0;
  return connectModulation(source, dest, amount, bipolar, range);
}

// set_lfo_shape(lfo_index, xs[], ys[], powers[], num_points): phase 0.5
// addition (see REPORT_PHASE05.md "LFO"). lfo_index is 1..8 (matches
// lfo_1..lfo_8). Rewrites the LFO's shared vital::LineGenerator -- the same
// object Vital's own LFO curve editor drags points on -- with an explicit,
// arbitrary user-drawn shape (x=phase in [0,1], y=value, both ends of the
// spec's kMaxPoints=100). Non-loop/non-smooth by default so the shape is
// reproduced exactly (straight segments between points, no smoothing that
// would distort a shape-correlation test); loop=true so it repeats
// periodically like every other LFO shape. Returns 1 on success, 0 if
// lfo_index or num_points is out of range.
EMSCRIPTEN_KEEPALIVE
int v2_set_lfo_shape(int lfo_index, const float* xs, const float* ys, const float* powers, int num_points) {
  if (!g_state || !g_state->engine || !xs || !ys || !powers)
    return 0;
  if (num_points < 2 || num_points > LineGenerator::kMaxPoints)
    return 0;
  if (lfo_index < 1 || lfo_index > vital::kNumLfos)
    return 0;

  LineGenerator* lg = g_state->engine->getLfoSource(lfo_index - 1);
  if (!lg)
    return 0;

  // M2 FIX (root cause of the M1 "lfo.draw -> pitch correlation sign
  // inverted" finding, |r|=0.99 but negative -- see REPORT_M2.md and
  // REPORT_PHASE1_M1.md item 4): LineGenerator::render()
  // (common/line_generator.cpp:189) computes `buffer_[i+1] = 1.0f - y`
  // from the raw points_ y-values -- i.e. the setPoint() y argument is in
  // an INVERTED "editor" convention where a HIGHER y produces a LOWER
  // actual output sample. Confirmed independently by LineGenerator's own
  // initSawUp() (line_generator.cpp:85-88), which stores DESCENDING points
  // {0,1}->{1,0} to produce what render() turns into an ASCENDING (rising
  // sawtooth) output buffer. grammar.mjs's lfo.draw({points}) spec (and
  // GRAMMAR.md's documented convention) uses the natural, non-inverted
  // meaning -- point value 1 = the drawn shape's peak/maximum modulation --
  // so it must be inverted here, once, at the C API boundary, rather than
  // making every JS caller remember Vital's internal editor-space quirk.
  lg->setNumPoints(num_points);
  for (int i = 0; i < num_points; ++i) {
    lg->setPoint(i, std::make_pair(xs[i], 1.0f - ys[i]));
    lg->setPower(i, powers[i]);
  }
  lg->setSmooth(false);
  lg->setLoop(true);
  lg->render();
  return 1;
}

EMSCRIPTEN_KEEPALIVE
int v2_get_num_parameters() {
  return vital::Parameters::getNumParameters();
}

// M2 diagnostic: the top-level SoundEngine's own getSampleRate() (Processor
// base, = last value passed to v2_create scaled by the ENGINE's own
// oversample_amount, which is never touched by SoundEngine::init()'s
// setOversamplingAmount() -- that call only recurses into voice_handler_/
// effect_chain_/output_total_, not the SoundEngine object itself) and its
// last-known oversampling amount (SoundEngine::getOversamplingAmount(),
// public). Added while root-causing the filter cutoff bug -- see REPORT_M2.md.
EMSCRIPTEN_KEEPALIVE
int v2_debug_engine_sample_rate() {
  if (!g_state || !g_state->engine) return -1;
  return g_state->engine->getSampleRate();
}

EMSCRIPTEN_KEEPALIVE
int v2_debug_oversampling_amount() {
  if (!g_state || !g_state->engine) return -1;
  return g_state->engine->getOversamplingAmount();
}

// See engine/patched_src/synthesis/filters/ladder_filter.cpp -- stashed on
// every LadderFilter::process() call.
extern float g_debug_ladder_sample_rate;
extern float g_debug_ladder_base_frequency;

EMSCRIPTEN_KEEPALIVE
float v2_debug_ladder_sample_rate() {
  return g_debug_ladder_sample_rate;
}

EMSCRIPTEN_KEEPALIVE
float v2_debug_ladder_base_frequency() {
  return g_debug_ladder_base_frequency;
}

// Debug-only introspection (added while diagnosing why process() produced
// silence -- kept, since it's useful for phase 1 work too).
EMSCRIPTEN_KEEPALIVE
int v2_debug_num_active_voices() {
  if (!g_state || !g_state->engine) return -1;
  return g_state->engine->getNumActiveVoices();
}

EMSCRIPTEN_KEEPALIVE
int v2_debug_num_pressed_notes() {
  if (!g_state || !g_state->engine) return -1;
  return g_state->engine->getNumPressedNotes();
}

// get_parameter_name(index, out_buf, buf_len): writes the index'th
// parameter's name into out_buf (null-terminated, truncated to buf_len-1).
// Lets JS enumerate the full Vital parameter set without hardcoding it.
EMSCRIPTEN_KEEPALIVE
int v2_get_parameter_name(int index, char* out_buf, int buf_len) {
  const vital::ValueDetails* details = vital::Parameters::getDetails(index);
  if (!details || !out_buf || buf_len <= 0)
    return 0;
  std::strncpy(out_buf, details->name.c_str(), buf_len - 1);
  out_buf[buf_len - 1] = '\0';
  return 1;
}

}  // extern "C"
