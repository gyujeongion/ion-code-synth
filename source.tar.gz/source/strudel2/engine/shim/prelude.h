// Force-included (via `emcc -include prelude.h`) ahead of every translation
// unit we compile. This works around a handful of include-hygiene bugs in
// this vendored Vital source snapshot: some headers use types/functions
// from other headers without including them themselves, and only compile
// in the upstream project because *some* other translation unit happens to
// include the missing header first (unity-build ordering, or simply luck
// of which .cpp happens to be compiled in the same TU). Since we compile
// each .cpp as its own TU with no guaranteed ordering, these gaps show up
// as real compile errors here. Each entry below documents exactly which
// bug it papers over. All of these headers are `#pragma once`, so
// force-including them everywhere is harmless.
#pragma once

// synthesis/filters/phaser_filter.h uses futils::midiOffsetToRatio() in an
// inline method body but never includes futils.h itself.
#include "futils.h"

// synthesis/modules/envelope_module.h forward-declares `class Envelope;`
// and then calls envelope_->setControlRate(...) in an inline method body,
// which needs the complete type.
#include "envelope.h"

// synthesis/modules/equalizer_module.h uses `StereoMemory` (defined in
// synthesis/lookups/memory.h) without including that header.
#include "memory.h"

// synthesis/synth_engine/sound_engine.cpp uses ChorusModule::kMaxDelayPairs
// without including chorus_module.h (it only includes compressor_module.h,
// flanger_module.h, phaser_module.h -- chorus is instantiated somewhere
// inside reorderable_effect_chain.h transitively, but the ChorusModule type
// itself isn't visible at sound_engine.cpp's point of use).
#include "chorus_module.h"
