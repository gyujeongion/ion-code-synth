// Minimal shim standing in for JUCE's generated JuceHeader.h.
// Vital's synthesis engine (src/synthesis, src/common) uses only a small
// sliver of JUCE from this header: two macros (leak-detector /
// non-copyable declarations that are no-ops without JUCE's leak
// tracking), a disableDenormalisedNumberSupport() call, and (in
// sample_source.cpp's JSON preset (de)serialization path only) a tiny
// String class + Base64 codec. Everything else in the engine is plain
// C++/STL and does not touch this header at all.
//
// Consequence of stubbing: no JUCE leak detection (irrelevant for a
// short-lived AudioWorklet instance) and no real denormal-flag control
// (wasm floats don't have configurable FTZ/DAZ the way x86 SSE does;
// this is a no-op either way on this target).
#pragma once

#include <string>
#include <cstdint>
#include <cstddef>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>

// ProjectInfo is normally Projucer-generated per-target (see e.g.
// vital-web/standalone/JuceLibraryCode/JuceHeader.h, read-only reference --
// not included in our build). versionString="1.0.6" matches that generated
// header's real value (JUCERPROJECT version="1.0.6" in vital.jucer) and is
// also the synth_version our presets carry after vital_compat.py's
// to_webvial() -- see engine/wrapper.cpp's v2_load_preset_json for where
// this is load-bearing (LoadSave::jsonToState's version-gate/migration
// logic compares a preset's synth_version against this string).
namespace ProjectInfo {
  const char* const projectName = "Vial";
  const char* const companyName = "Matt Tytel";
  const char* const versionString = "1.0.6";
  const int versionNumber = 0x10006;
}

#define JUCE_DECLARE_NON_COPYABLE(ClassName) \
    ClassName(const ClassName&) = delete; \
    ClassName& operator=(const ClassName&) = delete;

#define JUCE_LEAK_DETECTOR(ClassName)

#define JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ClassName) \
    JUCE_DECLARE_NON_COPYABLE(ClassName)

template <typename T>
static inline T jmin(T a, T b) { return a < b ? a : b; }
template <typename T>
static inline T jmax(T a, T b) { return a > b ? a : b; }
template <typename T>
static inline T jlimit(T lo, T hi, T v) { return v < lo ? lo : (v > hi ? hi : v); }

// Only method actually called by the engine: disableDenormalisedNumberSupport().
// wasm has no configurable FTZ/DAZ flag equivalent to x86 MXCSR, so this is a
// documented no-op stub (see header comment above).
class FloatVectorOperations {
  public:
    static void disableDenormalisedNumberSupport() { }
};

// Minimal String, standing in for juce::String. Exercised by two unrelated
// dead-in-our-usage paths that must still compile: Sample::stateToJson()/
// jsonToState() (preset JSON save/load; SampleModule/Sample is always
// linked in because SynthVoiceHandler unconditionally instantiates it, even
// though our C API never calls into sample loading) and common/tuning.cpp's
// Scala/.tun/.kbm file loaders (also always linked in, also never called by
// our wrapper -- we use Vital's default equal-temperament tuning). Because
// none of this is ever actually invoked at runtime, only compiled, exact
// behavioral fidelity (locale handling, unicode, etc.) doesn't matter here;
// this just needs to type-check against real juce::String call sites.
class String {
  public:
    String() = default;
    String(const std::string& s) : s_(s) {}
    String(const char* s) : s_(s ? s : "") {}
    String(char c) : s_(1, c) {}

    std::string toStdString() const { return s_; }
    int length() const { return static_cast<int>(s_.size()); }
    bool isEmpty() const { return s_.empty(); }
    char operator[](int i) const { return (i >= 0 && i < (int)s_.size()) ? s_[i] : '\0'; }

    String trim() const {
      size_t a = s_.find_first_not_of(" \t\r\n");
      if (a == std::string::npos) return String("");
      size_t b = s_.find_last_not_of(" \t\r\n");
      return String(s_.substr(a, b - a + 1));
    }

    String toLowerCase() const {
      std::string out = s_;
      std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) { return std::tolower(c); });
      return String(out);
    }

    bool contains(const char* needle) const { return s_.find(needle) != std::string::npos; }

    String substring(int start) const {
      if (start < 0) start = 0;
      if (start >= (int)s_.size()) return String("");
      return String(s_.substr(start));
    }
    String substring(int start, int end) const {
      if (start < 0) start = 0;
      if (end > (int)s_.size()) end = (int)s_.size();
      if (start >= end) return String("");
      return String(s_.substr(start, end - start));
    }

    String upToFirstOccurrenceOf(const String& substr, bool include_substring, bool ignore_case) const {
      std::string hay = ignore_case ? toLowerCase().s_ : s_;
      std::string needle = ignore_case ? substr.toLowerCase().s_ : substr.s_;
      size_t pos = hay.find(needle);
      if (pos == std::string::npos) return String(s_);
      size_t end = include_substring ? pos + needle.size() : pos;
      return String(s_.substr(0, end));
    }

    // NOTE (M7 fix -- caused an infinite recursion / wasm stack overflow in
    // LoadSave::compareVersionStrings, which recurses on
    // a.fromFirstOccurrenceOf("."...) until BOTH strings are empty): real
    // juce::String's four *OccurrenceOf variants do NOT all fall back to
    // "return the whole string" when the delimiter isn't found -- per
    // JUCE's own documented behavior, only the "upTo*" variants do that;
    // the "from*" variants return an EMPTY string instead. Getting this
    // wrong made a version string with no more "." characters left (e.g.
    // final segment "6" of "1.0.6") return itself unchanged forever instead
    // of terminating the recursion via isEmpty(). Fixed below; also fixed
    // pre-existing fromLastOccurrenceOf which had the same bug (not
    // previously exercised by any recursive caller, so it went unnoticed
    // until this milestone).
    String fromLastOccurrenceOf(const String& substr, bool include_substring, bool ignore_case) const {
      std::string hay = ignore_case ? toLowerCase().s_ : s_;
      std::string needle = ignore_case ? substr.toLowerCase().s_ : substr.s_;
      size_t pos = hay.rfind(needle);
      if (pos == std::string::npos) return String("");
      size_t start = include_substring ? pos : pos + needle.size();
      return String(s_.substr(start));
    }

    String upToLastOccurrenceOf(const String& substr, bool include_substring, bool ignore_case) const {
      std::string hay = ignore_case ? toLowerCase().s_ : s_;
      std::string needle = ignore_case ? substr.toLowerCase().s_ : substr.s_;
      size_t pos = hay.rfind(needle);
      if (pos == std::string::npos) return String(s_);
      size_t end = include_substring ? pos + needle.size() : pos;
      return String(s_.substr(0, end));
    }

    String fromFirstOccurrenceOf(const String& substr, bool include_substring, bool ignore_case) const {
      std::string hay = ignore_case ? toLowerCase().s_ : s_;
      std::string needle = ignore_case ? substr.toLowerCase().s_ : substr.s_;
      size_t pos = hay.find(needle);
      if (pos == std::string::npos) return String("");
      size_t start = include_substring ? pos : pos + needle.size();
      return String(s_.substr(start));
    }

    bool containsOnly(const char* allowed_chars) const {
      std::string allowed(allowed_chars);
      for (char c : s_) {
        if (allowed.find(c) == std::string::npos)
          return false;
      }
      return true;
    }

    String removeCharacters(const String& chars_to_remove) const {
      std::string remove_set = chars_to_remove.s_;
      std::string out;
      out.reserve(s_.size());
      for (char c : s_) {
        if (remove_set.find(c) == std::string::npos)
          out += c;
      }
      return String(out);
    }

    float getFloatValue() const { try { return std::stof(s_); } catch (...) { return 0.0f; } }
    int getIntValue() const { try { return std::stoi(s_); } catch (...) { return 0; } }

    String operator+(const String& other) const { return String(s_ + other.s_); }
    String operator+(const char* other) const { return String(s_ + other); }
    bool operator==(const String& other) const { return s_ == other.s_; }
    bool operator==(const char* other) const { return s_ == other; }
    bool operator!=(const String& other) const { return s_ != other.s_; }
    bool operator!=(const char* other) const { return s_ != other; }

  private:
    std::string s_;
};

inline String operator+(const char* lhs, const String& rhs) { return String(std::string(lhs) + rhs.toStdString()); }

// Minimal Base64 codec, standing in for juce::Base64. Only toBase64() and
// convertFromBase64() are used, both in the preset JSON path.
class Base64 {
  public:
    static String toBase64(const void* data, size_t size) {
      static const char* table =
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      const uint8_t* bytes = static_cast<const uint8_t*>(data);
      std::string out;
      out.reserve(((size + 2) / 3) * 4);
      size_t i = 0;
      while (i + 3 <= size) {
        uint32_t n = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
        out += table[(n >> 18) & 0x3F];
        out += table[(n >> 12) & 0x3F];
        out += table[(n >> 6) & 0x3F];
        out += table[n & 0x3F];
        i += 3;
      }
      size_t rem = size - i;
      if (rem == 1) {
        uint32_t n = bytes[i] << 16;
        out += table[(n >> 18) & 0x3F];
        out += table[(n >> 12) & 0x3F];
        out += "==";
      } else if (rem == 2) {
        uint32_t n = (bytes[i] << 16) | (bytes[i + 1] << 8);
        out += table[(n >> 18) & 0x3F];
        out += table[(n >> 12) & 0x3F];
        out += table[(n >> 6) & 0x3F];
        out += "=";
      }
      return String(out);
    }

    static bool convertFromBase64(const std::string& in, std::vector<uint8_t>& out) {
      auto decodeChar = [](char c) -> int {
        if (c >= 'A' && c <= 'Z') return c - 'A';
        if (c >= 'a' && c <= 'z') return c - 'a' + 26;
        if (c >= '0' && c <= '9') return c - '0' + 52;
        if (c == '+') return 62;
        if (c == '/') return 63;
        return -1;
      };
      out.clear();
      uint32_t buffer = 0;
      int bits = 0;
      for (char c : in) {
        int v = decodeChar(c);
        if (v < 0) continue;
        buffer = (buffer << 6) | static_cast<uint32_t>(v);
        bits += 6;
        if (bits >= 8) {
          bits -= 8;
          out.push_back(static_cast<uint8_t>((buffer >> bits) & 0xFF));
        }
      }
      return true;
    }

    // Overload used by Sample::jsonToState(): decode base64 text directly
    // into a MemoryOutputStream (see below).
    static bool convertFromBase64(class MemoryOutputStream& out, const std::string& in);
};

// Minimal stand-in for juce::MemoryOutputStream, used only as the decode
// target in Sample::jsonToState() (preset load path).
class MemoryOutputStream {
  public:
    MemoryOutputStream() = default;
    explicit MemoryOutputStream(size_t reserve) { data_.reserve(reserve); }
    void write(const void* src, size_t n) {
      const uint8_t* b = static_cast<const uint8_t*>(src);
      data_.insert(data_.end(), b, b + n);
    }
    const void* getData() const { return data_.data(); }
    size_t getDataSize() const { return data_.size(); }
  private:
    std::vector<uint8_t> data_;
};

inline bool Base64::convertFromBase64(MemoryOutputStream& out, const std::string& in) {
  std::vector<uint8_t> decoded;
  convertFromBase64(in, decoded);
  if (!decoded.empty())
    out.write(decoded.data(), decoded.size());
  return true;
}

// Minimal StringArray, used only by common/tuning.cpp's Scala/.tun/.kbm file
// parsers (dead code in our usage -- see String comment above).
class StringArray {
  public:
    StringArray() = default;

    void addTokens(const String& source, bool /*preserve_quotes*/) {
      std::istringstream iss(source.toStdString());
      std::string tok;
      while (iss >> tok)
        items_.push_back(String(tok));
    }

    void addTokens(const String& source, const String& break_chars, const String& /*quote_chars*/) {
      std::string src = source.toStdString();
      std::string breaks = break_chars.toStdString();
      size_t start = 0;
      while (start <= src.size()) {
        size_t pos = src.find_first_of(breaks, start);
        if (pos == std::string::npos) {
          items_.push_back(String(src.substr(start)));
          break;
        }
        items_.push_back(String(src.substr(start, pos - start)));
        start = pos + 1;
      }
    }

    void clear() { items_.clear(); }
    void add(const String& s) { items_.push_back(s); }
    int size() const { return static_cast<int>(items_.size()); }
    String operator[](int i) const { return (i >= 0 && i < (int)items_.size()) ? items_[i] : String(""); }
    std::vector<String>::const_iterator begin() const { return items_.begin(); }
    std::vector<String>::const_iterator end() const { return items_.end(); }

  private:
    std::vector<String> items_;
};

// Minimal File, used only by common/tuning.cpp's Scala/.tun/.kbm file
// loaders (dead code in our usage -- see String comment above). readLines()
// is implemented for honesty (it's trivial) even though nothing in the spike
// calls it.
class File {
  public:
    File() = default;
    explicit File(const std::string& path) : path_(path) {}

    String getFileExtension() const {
      size_t dot = path_.find_last_of('.');
      if (dot == std::string::npos) return String("");
      return String(path_.substr(dot));
    }

    String getFileNameWithoutExtension() const {
      size_t slash = path_.find_last_of("/\\");
      std::string base = (slash == std::string::npos) ? path_ : path_.substr(slash + 1);
      size_t dot = base.find_last_of('.');
      if (dot != std::string::npos) base = base.substr(0, dot);
      return String(base);
    }

    bool readLines(StringArray& out) const {
      std::ifstream in(path_);
      if (!in.is_open())
        return false;
      std::string line;
      while (std::getline(in, line))
        out.add(String(line));
      return true;
    }

  private:
    std::string path_;
};
