// Stub for third_party pffft's pffft.h. common/fourier_transform.h does an
// unconditional `#include <pffft.h>` even though we build with
// -DUSE_PFFFT=0 -DUSE_KISSFFT=1 (see build.sh) -- the whole PFFFT-backed
// FourierTransform class is compiled out by the preprocessor in that case,
// so this header only needs to exist and parse; none of its symbols are
// ever referenced. We deliberately avoid building real PFFFT (its .c
// sources live under vital-web/standalone/builds/wasm_full/pffft and are
// tied to that build's own Makefile) since KISSFFT (header-only C++,
// already vendored, no build-system dependency) is a fully equivalent
// substitute for this spike -- see REPORT.md "stubbed" section.
#pragma once
